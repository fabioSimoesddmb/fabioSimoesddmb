//
//  ViewController.swift
//  RGB_fabioSimoes_t2_ddmb

//Created by Fábio Simões on 23/05/2019.
//  Copyright © 2019 ISTECaluno. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var labelcolor:UILabel?
    var labelrgba:UILabel?
    var labelR:UILabel?
    var labelG:UILabel?
    var labelB:UILabel?
    var labelA:UILabel?
    
    var Red = 0;
    var Green = 0;
    var Blue = 0;
    var Alpha = 255;
    
    override func viewDidLoad() {
        super.viewDidLoad();
        
        
        labelcolor = UILabel(frame: CGRect(x: 100, y: 75, width: 300, height: 300));
        labelcolor?.center.x = self.view.center.x;
        
        labelrgba = UILabel(frame: CGRect(x: 65, y: 400, width: 350, height:50));
        labelrgba?.text = "Red: \(Red) Green: \(Green) Blue: \(Blue) Alpha: \(Alpha)";
        
        labelR = UILabel(frame: CGRect(x: 50, y: 520, width: 20, height:20));
        labelR?.text = "R";
        
        labelG = UILabel(frame: CGRect(x: 50, y: 580, width: 20, height:20));
        labelG?.text = "G";
        
        labelB = UILabel(frame: CGRect(x: 50, y: 620, width: 20, height:20));
        labelB?.text = "B";
        
        labelA = UILabel(frame: CGRect(x: 50, y: 680, width: 20, height:20));
        labelA?.text = "A";

        
        let colorRed = UISlider(frame: CGRect(x: 100, y: 500, width: 200, height: 80));
        colorRed.minimumValue = 0;
        colorRed.maximumValue = 255;
        colorRed.addTarget(self, action: #selector(toRed), for: .valueChanged);
        
        let colorGreen = UISlider(frame: CGRect(x: 100, y: 550, width: 200, height: 80));
        colorGreen.minimumValue = 0;
        colorGreen.maximumValue = 255;
        colorGreen.addTarget(self, action: #selector(toGreen), for: .valueChanged);
        
        let colorBlue = UISlider(frame: CGRect(x: 100, y: 600, width: 200, height: 80));
        colorBlue.minimumValue = 0;
        colorBlue.maximumValue = 255;
        colorBlue.addTarget(self, action: #selector(toBlue), for: .valueChanged);
        
        let colorAlpha = UISlider(frame: CGRect(x: 100, y: 650, width: 200, height: 80));
        colorAlpha.minimumValue = 0;
        colorAlpha.maximumValue = 255;
        colorAlpha.addTarget(self, action: #selector(toAlpha), for: .valueChanged);
        
        
        self.view.addSubview(labelcolor!);
        self.view.addSubview(labelrgba!);
        self.view.addSubview(labelR!);
        self.view.addSubview(labelG!);
        self.view.addSubview(labelB!);
        self.view.addSubview(labelA!);
        self.view.addSubview(colorRed);
        self.view.addSubview(colorGreen);
        self.view.addSubview(colorBlue);
        self.view.addSubview(colorAlpha);
    }
    
    @objc func toRed (_ sender:UISlider){
        Red = Int(sender.value);
        toCallColor();
    }
    
    @objc func toGreen (_ sender:UISlider){
        Green = Int(sender.value);
        toCallColor();
    }
    
    @objc func toBlue(_ sender:UISlider){
        Blue = Int(sender.value);
        toCallColor();
    }
    
    @objc func toAlpha(_ sender:UISlider){
        Alpha = Int(sender.value);
        toCallColor();
    }
    
    @objc func toCallColor(){
        labelcolor?.backgroundColor = UIColor(red: CGFloat(Red)/255, green: CGFloat(Green)/255, blue: CGFloat(Blue)/255, alpha: CGFloat(Alpha)/255);
        labelrgba?.text = "Red: \(String(Red)) Green: \(String(Green)) Blue: \(String(Blue)) Alpha: \(String(Alpha))";
        
    }
    
}



